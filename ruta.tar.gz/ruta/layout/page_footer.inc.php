        <div class="" data-role="footer" data-theme="" style="">
			<p aria-level="1" role="heading" class="ui-title" style="color:#aaa; text-align:left;">
				©2021 Ruta-Mobile<small> by
				<a href="http://www.lufemansoftware.com" style="text-decoration:none;">LufemanSoftware</a></small>
			</p>
        </div>
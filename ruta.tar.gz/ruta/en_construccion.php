<?php 
require_once('qcubed.inc.php');
include('layout/header.inc.php');
$strTituPagi = "404";
?>

    <div data-role="page" id="construccion">

        <?php include('layout/page_header.inc.php'); ?>

        <div data-role="content" style="text-align: center; min-height: 200px; padding-top: 10%">
            <img src="images/Logo_Servex.png" alt="" style="opacity:0.5;">
            <hr>
            <h3>Página en Construcción</h3><h4>(Próximamente!)</h4>
            <p>Esta página no esta disponible por el momento, disculpe las molestias y disfrute de las demás opciones que la aplicación le ofrece.</p>
        </div>

        <?php include('layout/page_footer.inc.php'); ?>

    </div>

<?php include('layout/footer.inc.php'); ?>